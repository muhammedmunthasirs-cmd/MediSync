# MediSync

AI-assisted healthcare information management. MediSync pulls a patient's
scattered documents — prescriptions, lab reports, consultation notes, scans,
discharge summaries — into one chronological timeline, and automatically
flags missing or conflicting information (allergy/medication matches,
inconsistent dosages, undated documents) for a clinician to review.

**MediSync organizes and surfaces information. It does not diagnose,
prescribe, or make medical decisions — those stay with qualified healthcare
professionals**, and every automated flag is designed to be checked in a
few seconds, not trusted blindly.

This repository contains a complete, runnable full-stack implementation:

- `backend/` — FastAPI + SQLite REST API: auth, patients, document upload,
  text extraction (PDF text layer / OCR), rule-based clinical field
  extraction, timeline assembly, and conflict detection.
- `frontend/` — a dependency-free HTML/CSS/JS single-page app (no build
  step) that talks to the API.

---

## 1. Run the backend

Requires **Python 3.10+**.

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**Optional but recommended — OCR support.** Scanned images/PDFs (rather
than PDFs with a real text layer) are read with Tesseract OCR via
`pytesseract`. Install the system binary:

```bash
# macOS
brew install tesseract
# Ubuntu/Debian
sudo apt-get install tesseract-ocr
# Windows: https://github.com/UB-Mannheim/tesseract/wiki
```

If you skip this, the app still runs fine — PDFs with a real text layer and
`.txt` uploads work either way, and scanned images will just be marked
"needs review" instead of auto-extracted.

**(Optional) Seed a demo account and patient:**

```bash
python seed_demo.py
```
This creates `demo@medisync.local` / `DemoPass123!` and one sample patient.

**Start the API:**

```bash
uvicorn app.main:app --reload --port 8000
```

The API is now at `http://localhost:8000`. Interactive API docs (Swagger
UI) are auto-generated at `http://localhost:8000/docs`.

## 2. Run the frontend

No build step — it's plain HTML/CSS/JS. Simplest option, from the
`frontend/` directory:

```bash
cd frontend
python3 -m http.server 5500
```

Then open `http://localhost:5500` in your browser.

By default the frontend calls the API at `http://localhost:8000`. To point
it elsewhere (e.g. a deployed backend), set this before `app.js` loads —
add a line to `index.html` right above `<script src="app.js">`:

```html
<script>window.MEDISYNC_API_BASE = "https://your-api-host.example.com";</script>
```

## 3. Try it out

1. Sign in with the seeded demo account, or register a new one.
2. Create a patient (or use the seeded "Asha Verma").
3. Upload a document — try a `.txt` file first since it needs no OCR setup.
   A sample is below.
4. Watch it appear on the **Timeline** tab, and check the **Flags** tab for
   anything MediSync noticed automatically.

**Sample prescription text** (save as `sample_rx.txt` and upload as type
"Prescription" to see extraction + a conflict flag against the seeded
patient's Penicillin allergy):

```
Consultation Note - City Clinic
Date: 2024-03-15

Diagnosis: Upper respiratory tract infection

Medications:
Amoxicillin 500mg - twice daily

Allergies: none reported by patient today
```

---

## How the "AI" layer works, and how to extend it

Document intelligence lives entirely in `backend/app/services/`:

- **`extraction.py`** — turns a file into text (PDF text layer, else OCR via
  Tesseract) and then into structured fields (medications, dosages,
  diagnoses, allergies, lab values, dates) using a transparent, inspectable
  set of regex/keyword rules. Every router and the conflict engine depend
  only on the `structured_data` dict shape documented at the top of that
  file — **not** on how it was produced. That means you can swap
  `extract_fields()` for a call to a real medical NLP model or an LLM (for
  example the Anthropic API) without touching anything else in the app.
- **`conflicts.py`** — re-scans a patient's full document set on every
  upload/edit/delete and raises explainable flags: allergy vs. prescribed
  medication matches, conflicting dosages for the same drug across
  prescriptions, undated documents, and missing allergy status. Each flag
  names exactly which document(s) and field(s) triggered it.

## Architecture notes / production hardening checklist

This is a complete, working MVP, not a production deployment. Before real
patient data touches this:

- **Compliance**: handling real PHI requires HIPAA (or local equivalent)
  compliant infrastructure — encryption at rest, audit logging of every
  record access, a signed BAA with any cloud provider, access controls
  beyond the simple role field here, etc. None of that is in place yet.
- **Secrets**: set `MEDISYNC_SECRET_KEY` to a strong random value via
  environment variable; the default in `config.py` is dev-only.
- **CORS**: `main.py` currently allows all origins for local development —
  restrict `allow_origins` to your real frontend domain.
- **File storage**: documents are stored on local disk under
  `backend/storage/`. For production, use encrypted object storage
  (e.g. S3 with server-side encryption) instead.
- **Extraction pipeline**: runs synchronously inside the upload request.
  Move it to a background worker (Celery, RQ, or FastAPI `BackgroundTasks`
  backed by a queue) once documents are large/numerous, and add retry logic.
- **Database**: SQLite is fine for a demo; move to PostgreSQL for
  concurrent multi-user use.
- **Auth**: add password reset, MFA, and session revocation before any
  real clinical use; the current JWT setup is intentionally minimal.
